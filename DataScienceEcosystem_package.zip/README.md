# Data Science Tools and Ecosystem

This repository contains the final project notebook **DataScienceEcosystem.ipynb** for the course.  
The notebook summarizes important concepts in Data Science including tools, libraries, and basic operations.

## 📑 Contents

The notebook includes the following exercises:

1. Create a Jupyter Notebook  
2. Add a title using Markdown  
3. Add an introduction  
4. List popular Data Science languages  
5. List commonly used Data Science libraries  
6. Create a table of Data Science tools  
7. Introduce arithmetic expression examples  
8. Multiply and add numbers (Python code)  
9. Convert minutes to hours (Python code)  
10. List notebook objectives  
11. Add author information  
12. Share the notebook on GitHub  
13. Provide screenshots of the notebook  

## 🚀 Usage

1. Clone this repository:
   ```bash
   git clone <your-repo-link>
   ```

2. Open the notebook in Jupyter Notebook, JupyterLite, or JupyterLab:
   ```bash
   jupyter notebook DataScienceEcosystem.ipynb
   ```

3. Run the cells to see outputs and results.

## 📸 Screenshots

Screenshots of each exercise are included as part of the assignment submission:
- `1-notebook.png`
- `2-title.png`
- `3-intro.png`
- `4-dslanguages.png`
- `5-dslibraries.png`
- `6-dstools.png`
- `7-introarithmetic.png`
- `8-multiplyandaddintegers.png`
- `9-hourstominutes.png`
- `10-objectives.png`
- `11-authordetails.png`

## 👤 Author

Fofana Djiguiba
